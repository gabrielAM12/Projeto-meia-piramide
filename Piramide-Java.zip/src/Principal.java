import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int i = 0, nlinha = 1, a, menor, somamenores = 0;
		int qtdelinha = 0;

		System.out.println("String: ");

		String str = teclado.nextLine();

		String[] vetorstr = str.split(" ");

		int tamanho = vetorstr.length;
		int[] numeros = new int[vetorstr.length];
		System.out.println("Lista: [" + str + "]");
		System.out.println("----------------------------------------------");
		System.out.println("-- Pirâmide --");
		System.out.println();
		// Loop para transformar a string dos números digitados pelo usuário em inteiro
		for (i = 0; i < tamanho; i++) {
			numeros[i] = Integer.parseInt(vetorstr[i]);
		}
		i = 0;
		/* Loop para quebrar linha, pegar o menor número de cada linha e somar os menores números 
		e ao final do loop printar o resultado */
		
		while (i < tamanho) {
			menor = numeros[i];

			for (a = 0; a < nlinha; a++) {
				if (i < tamanho) {
					System.out.print(numeros[i] + " ");
					if (numeros[i] < menor) {
						menor = numeros[i];

					}

					i++;

				}

			}
			somamenores += menor;
			System.out.println();
			nlinha++;

		}
		
		
		qtdelinha= nlinha-1;
		int[] menores = new int[qtdelinha];
		// Loop para armazenar os menores números de cada linha em um vetor
		for (i=0,nlinha=1;i < tamanho; nlinha++) {
			menor = numeros[i];

			for (a = 0; a < nlinha; a++) {
				if (i < tamanho) {
					if (numeros[i] < menor) {
						menor = numeros[i];

					}

					i++;

				}
			}
			menores[nlinha-1]=menor;
			
		}

		System.out.println();
		
		// Sistema para exibir os menores números de cada linha dentro do vetor
		System.out.print("Os menores valores são: ");
		System.out.print("[");
		for (i = 0; i < qtdelinha; i++) {
			if (i == qtdelinha - 1) {
				System.out.print(menores[i]);
			} else {
				System.out.print(menores[i] + " ");
			}
		}
		System.out.print("]");
		
		System.out.println();
		System.out.println("A soma dos menores números de cada linha é: " + somamenores);
	}

}
